# ORBITA Identity & Career Services API (SOA & WebServices)

API ASP.NET Core 8 com:
- Entity Framework Core (SQL Server)
- JWT (autenticação STATELESS)
- Autorização por perfis (Student, Mentor, Admin)
- Versionamento de API (/api/v1, /api/v2)
- Tratamento global de exceções (middleware)
- Respostas padronizadas (ApiResponse<T>)
- Serviços de negócio separados da camada de API

## Como rodar

1. Ajuste a connection string em `appsettings.json` se necessário.
2. No diretório do projeto:

```bash
dotnet restore
dotnet run
```

3. Acesse o Swagger em:
- `https://localhost:7180/swagger` (porta pode variar)

## Fluxo de teste rápido

1. **Registrar usuário Student**  
   `POST /api/v1/Auth/register`  
   Body:
   ```json
   {
     "name": "Kaue",
     "email": "kaue@example.com",
     "password": "Senha123",
     "weeklyAvailableHours": 10
   }
   ```

2. **Login**  
   `POST /api/v1/Auth/login`  
   (usa o mesmo e-mail e senha) → copiar o `token`.

3. **Authorize no Swagger**  
   Clicar em **Authorize** e informar:  
   `Bearer SEU_TOKEN_AQUI`

4. **Criar rota de carreira (necessário usuário com role Admin/Mentor)**  
   Ajustar role direto no banco ou via endpoint `/api/v1/Users/{id}/role` (Admin).

5. **Criar missões**  
   `POST /api/v1/Missions` com o `careerPathId` criado.

6. **Registrar progresso**  
   Com usuário Student logado:  
   `POST /api/v1/Progress`

7. **Atualizar status para Concluida**  
   `PUT /api/v1/Progress/{id}/status` com body `"Concluida"`.

8. **Listar progresso do aluno logado**  
   `GET /api/v1/Progress`

Isso demonstra autenticação, autorização, regras de negócio via serviços, integração com banco e versionamento da API.
