using Microsoft.AspNetCore.Mvc;

namespace Orbita.SoaApi.Api.Controllers
{
    [ApiController]
    [ApiVersion("2.0")]
    [Route("api/v{version:apiVersion}/[controller]")]
    public class CareerPathsController : ControllerBase
    {
        [HttpGet]
        public IActionResult Get()
        {
            return Ok(new
            {
                version = "2.0",
                message = "Exemplo de versão v2 da API ORBITA para demonstração de versionamento."
            });
        }
    }
}
