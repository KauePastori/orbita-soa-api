namespace Orbita.SoaApi.Application.DTOs.Users
{
    public class UpdateUserRoleRequest
    {
        public string Role { get; set; } = null!;
    }
}
