namespace Orbita.SoaApi.Domain.Enums
{
    public enum UserRole
    {
        Student = 0,
        Mentor = 1,
        Admin = 2
    }
}
