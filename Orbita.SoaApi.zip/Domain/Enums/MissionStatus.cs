namespace Orbita.SoaApi.Domain.Enums
{
    public enum MissionStatus
    {
        Pendente = 0,
        EmAndamento = 1,
        Concluida = 2
    }
}
